import pandas as pd
import numpy as np
from collections import defaultdict

def compute_wallet_features(transactions_df):
    """
    Computes per-wallet behavioral features from Aave transaction DataFrame.
    Expects 'userWallet' as the wallet address field.
    """
    wallet_features = defaultdict(lambda: defaultdict(float))

    transactions_df['timestamp'] = pd.to_datetime(transactions_df['timestamp'])

    for _, row in transactions_df.iterrows():
        try:
            wallet = row['userWallet']
            action = row['action']  

            
            action_data = row.get("actionData", {})
            amount = float(action_data.get('amount', 0))

            
            wallet_features[wallet][f'num_{action}'] += 1
            wallet_features[wallet][f'total_{action}_amount'] += amount
            wallet_features[wallet]['total_txns'] += 1
            wallet_features[wallet]['total_volume'] += abs(amount)

            
            ts = row['timestamp']
            wallet_features[wallet]['last_activity'] = max(wallet_features[wallet].get('last_activity', pd.Timestamp.min), ts)

        except Exception as e:
            print(f"⚠️ Skipping row due to error: {e}")

    
    df = pd.DataFrame.from_dict(wallet_features, orient='index').fillna(0)

    
    df['borrow_deposit_ratio'] = df['total_borrow_amount'] / (df['total_deposit_amount'] + 1)
    df['liquidation_ratio'] = df['num_liquidationcall'] / (df['total_txns'] + 1)
    df['net_deposit'] = df['total_deposit_amount'] - df['total_borrow_amount']

    
    return df.reset_index().rename(columns={'index': 'wallet_address'})
