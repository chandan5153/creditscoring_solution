import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def score_wallets(df):
    """
    Assign scores between 0–1000 using normalized risk heuristics.
    """
    df = df.copy()

    features_to_use = ['borrow_deposit_ratio', 'liquidation_ratio', 'net_deposit', 'total_txns']
    df[features_to_use] = df[features_to_use].fillna(0)

    
    df['risk_score'] = (
        0.5 * df['borrow_deposit_ratio'] +
        0.4 * df['liquidation_ratio'] -
        0.1 * df['net_deposit']
    )

    scaler = MinMaxScaler()
    df['norm_score'] = scaler.fit_transform(-df[['risk_score']])  

    df['credit_score'] = (df['norm_score'] * 1000).astype(int).clip(0, 1000)

    return df[['wallet_address', 'credit_score']]
