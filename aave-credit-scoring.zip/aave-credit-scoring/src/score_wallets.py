import json
import pandas as pd
from feature_engineering import compute_wallet_features
from model import score_wallets
import argparse
import os

def main(input_path, output_path):
    with open(input_path, 'r') as f:
        raw_data = json.load(f)

    print("✅ Loaded transactions:", len(raw_data))
    print(" Sample keys in first record:", list(raw_data[0].keys()))

    transactions = pd.DataFrame(raw_data)

    wallet_features = compute_wallet_features(transactions)
    scores_df = score_wallets(wallet_features)

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    scores_df.to_csv(output_path, index=False)
    print(f"✅ Scored {len(scores_df)} wallets → saved to {output_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to user_transactions.json")
    parser.add_argument("--output", default="output/wallet_scores.csv", help="Path to output CSV")
    args = parser.parse_args()

    main(args.input, args.output)
